print("1. feladat")
aktiv = input("Adja meg az aktivitását: ")

print("2. feladat")
uszas = aktiv.count("U")
gyalog = aktiv.count("G")
futas = aktiv.count("F")
kerekpar = aktiv.count("K")

tav = uszas + gyalog + futas * 2 + kerekpar * 10
print("Az elért távolság: {0} km.".format(tav))

print("3. feladat")
if (uszas != 0 and gyalog != 0 and futas != 0 and kerekpar != 0):
    print("Bravó! Jutalma még 10 km.")
else:
    print("Nem jár jutalom.")

print("4. feladat")
if tav + 10 > 40:
    print("Eredménye: {0} km. Gratulálok, kihívás teljesítve!".format(tav+10))
else:
    print("Legközelebb sikerül!")