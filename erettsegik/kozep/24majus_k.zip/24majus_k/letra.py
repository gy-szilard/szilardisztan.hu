dobasok = [3, 1, 1, 2, 1, 5, 5, 4, 4, 4, 1, 2, 3, 6, 4, 6, 1, 4]

print("2. feladat")
szamlalo = 0
vissza = 0
for i in dobasok:
    szamlalo += i
    if szamlalo % 10 == 0:
        szamlalo -= 3
        vissza += 1
    print(szamlalo, end=" ")

print("\n3. feladat")
print(f"A játék során {vissza} alkalommal lépett létrára.")

print("4. feladat")
if szamlalo >= 45:
    print("A játékot befejezte.")
else:
    print("A játékot abbahagyta.")