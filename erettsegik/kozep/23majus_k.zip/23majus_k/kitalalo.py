import random

szavak = ["fuvola", "csirke", "adatok", "asztal", "fogoly", "bicska", "farkas", "almafa", "babona", "gerinc", "dervis", "bagoly", "ecetes", "angyal", "boglya"]

jatek = True
proba = 0
while jatek:
    szo = random.choice(szavak)
    tipp = input("Kérem a tippet: ")
    proba += 1
    eredmeny = ""
    if tipp == "stop":
        jatek = False
    else:
        for i in range(len(szo)):
            if szo[i] == tipp[i]:
                eredmeny += szo[i]
            else:
                eredmeny += "."
        if eredmeny == szo:
            print(f"Az eredmény: {eredmeny}")
            print(f"{proba} tippeléssel sikerült kitalálni.")
            break
        else:
            print(f"Az eredmény: {eredmeny}")