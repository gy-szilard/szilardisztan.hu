uvegek = [5, 2, 2, 4, 3, 2, 4, 10, 5, 5, 3, 5, 4, 3, 3]

print("2. feladat")
L = int(input("Mari néni lekvárja (dl): "))

print("3. feladat")
legnagyobb = max(uvegek)
for i in range(len(uvegek)):
    if legnagyobb == uvegek[i]:
        print(f"A legnagyobb üveg: {legnagyobb} dl, és {i+1}. a sorban.")
        break

print("4. feladat")
if sum(uvegek) >= L:
    print("Elegendő üveg volt.")
else:
    print("Maradt lekvár.")