parancs = input("Kérem a robot parancsait: ")
e = parancs.count("E")
k = parancs.count("K")
d = parancs.count("D")
n = parancs.count("N")

print(f"E betűk száma {e}")
print(f"D betűk száma {d}")
print(f"K betűk száma {k}")
print(f"N betűk száma {n}")

rovid = ""
if e-d > 0:
    rovid += "E" * abs(d-e)
else:
    rovid += "D" * abs(d-e)
if k-n > 0:
    rovid += "K" * abs(n-k)
else:
    rovid += "N" * abs(n-k)

print(f"Egy rövidebb út parancsszava: {rovid}")