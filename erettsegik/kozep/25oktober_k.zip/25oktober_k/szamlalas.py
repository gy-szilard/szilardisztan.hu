meres = [36, 48, 39, -1, 30, 43, -1, 76, 67, 82, 73, 75, 64, 73, 69, 63]

print("2. feladat")
ossz = 0
for i in meres:
    if i != -1:
        ossz += i
print(f"Összesen {ossz} kerékpárost számoltak.")

print("3. feladat")
print("Óránkénti mérések:")
szamlalo = 0
szamok = 0
ora = 6
for i in meres:
    szamlalo += 1
    if i != -1:
        szamok += i
    if szamlalo == 4:
        print(f"{ora} órától {szamok} kerékpáros")
        szamlalo = 0
        szamok = 0
        ora += 1

print("4. feladat")
max_szam = max(meres)
max_ido = 375
for i in meres:
    if i == max_szam:
        print(f"Az áthaladók maximális száma: {max_szam}; rögzítési időpontja: {max_ido//60}:{max_ido%60}")
        break
    else:
        max_ido += 15
