tomeg = [16, 8, 9, 4, 3, 2, 4, 7, 7, 12, 3, 5, 4, 3, 2]

print("2. feladat")
print(f"A tárgyak tömegének összege: {sum(tomeg)} kg")

print("3. feladat")
dobozok = []
szamlalo = 0
for i in tomeg:
    if szamlalo + i > 20:
        dobozok.append(szamlalo)
        szamlalo = 0
    szamlalo += i

if szamlalo > 0:
    dobozok.append(szamlalo)

print("A dobozok tartalmának tömege (kg): ", end="")
for i in dobozok:
    print(i, end=" ")
print(f"\nA szükséges dobozok száma: {len(dobozok)}")