adatok = [865,846,831,820,808,783,788,775,752,750,743,745,758,770]

#2. feladat
print(f"A legkisebb mért érték: {min(adatok)}")
print(f"A legkisebb mérési adat sorszáma: {adatok.index(min(adatok))+1}")

#3. feladat
keresett = int(input("Minél kisebb mérési értéket keres? (egész szám) "))
kisebb = 0
for i in adatok:
    if i < keresett:
        kisebb += 1
print(f"{keresett} alatti mérések száma: {kisebb}")

#4. feladat
csokkenes = adatok[0] - adatok[1]
for i in range(len(adatok)):
    if adatok[i] != adatok[-1]:
        if abs(adatok[i] - adatok[i+1]) > csokkenes:
            csokkenes = abs(adatok[i] - adatok[i+1])
print(f"A két mérés közötti legnagyobb csökkenés: {csokkenes}")