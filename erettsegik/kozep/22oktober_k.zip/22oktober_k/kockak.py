import random

N = int(input("Hány alkalommal legyen a feldobás? "))

Anni = 0
Panni = 0

for i in range(N):
    dobas1 = random.randint(1, 6)
    dobas2 = random.randint(1, 6)
    dobas3 = random.randint(1, 6)
    if dobas1 + dobas2 + dobas3 < 10:
        Anni += 1
        print(f"Dobás: {dobas1} + {dobas2} + {dobas3} = {dobas1+dobas2+dobas3}\tNyert: Anni")
    else:
        Panni += 1
        print(f"Dobás: {dobas1} + {dobas2} + {dobas3} = {dobas1+dobas2+dobas3}\tNyert: Panni")
print(f"A játék során {Anni} alkalommal Anni, {Panni} alkalommal Panni nyert.")

