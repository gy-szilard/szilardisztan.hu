print("1. feladat")
azonosito = input("Kérem adja meg az autó azonosítóját! ")
adatok = []

with open(f"{azonosito}.txt", "r") as ff:
    for sor in ff:
        s = sor.strip().split("\t")
        s_int = [int(s[0]), int(s[1]), int(s[2])]
        adatok.append(s_int)

print("2. feladat")
print(f"Az autó a {adatok[0][0]}. másodpercben indult el.")
print(f"Az autó a megfigyelés végén {adatok[-1][2]} m/s sebességgel haladt.")

print("3. feladat")
max_sebesseg = adatok[0][2]

for i in adatok:
    if i[2] > max_sebesseg:
        max_sebesseg = i[2]
if max_sebesseg > 14:
    print("Az autó átlépte a sebességhatárt.")
else:
    print("Az autó nem lépte át a sebességhatárt.")

print("4. feladat")
max_allás = adatok[0][0] - 0
intervallum = []

for i in range(len(adatok) - 1):
    if adatok[i][2] == 0:
        időtartam = adatok[i + 1][0] - adatok[i][1]

        if időtartam > max_allás:
            max_allás = időtartam
            intervallum = [adatok[i][1], adatok[i + 1][0]]

print(f"A leghosszabb állásidő {intervallum[0]} és {intervallum[1]} másodperc között volt.")


print("5. feladat")
mikor = int(input("Mikor vizsgáljuk az autó sebességét? "))

pill_seb = 0.0
for i in range(len(adatok)):
    kezd_ido = adatok[i][0]
    veg_ido = adatok[i][1]
    veg_seb = adatok[i][2]

    kezd_seb = adatok[i - 1][2] if i > 0 else 0

    if kezd_ido <= mikor <= veg_ido:
        pill_seb = kezd_seb + ((veg_seb - kezd_seb) / (veg_ido - kezd_ido)) * (mikor - kezd_ido)
        break

    if i < len(adatok) - 1 and veg_ido < mikor < adatok[i + 1][0]:
        pill_seb = veg_seb
        break

print(f"Az autó sebessége a(z) {mikor}. másodpercben {round(pill_seb, 1)} m/s volt.")

print("6. feladat")
osszes_ut = 0.0
t_akt = 0
v_akt = 0

for i in adatok:
    osszes_ut += v_akt * (i[0] - t_akt) + ((v_akt + i[2]) / 2) * (i[1] - i[0])
    t_akt, v_akt = i[1], i[2]

print(f"A megtett út: {osszes_ut} méter.")

#print("7. feladat")
with open(f"v{azonosito}.txt", "w") as ff:
    aktual = 0
    for i in adatok:
        ff.write(str(i[0]) + "\t" + str(aktual) + "\n")
        aktual = i[2]
        ff.write(str(i[1]) + "\t" + str(aktual) + "\n")
