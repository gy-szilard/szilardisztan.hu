adatok = []
tavolsag = 0

with open("ut.txt", "r", encoding="UTF-8") as ff:
    for i in ff:
        adatok.append(i.strip().split())
    tavolsag = int(adatok[0][0])
    adatok.pop(0)

print(tavolsag)

print("2. feladat")
for i in adatok:
    if 3 < len(i[1]) < 31:
        print(i[1])

print("\n3. feladat")
km = float(input("Adja meg a vizsgált szakasz hosszát km-ben! "))
legkisebb = 90
for i in adatok:
    if int(i[0]) > km * 1000:
        break
    elif i[1][0].isdigit():
        legkisebb = int(i[1])
    elif len(i[1]) > 3:
        if legkisebb > 50:
            legkisebb = 50

print(f'Az első {km} km-en {legkisebb} km/h volt a legalacsonyabb megengedett sebesség.')

print("\n4. feladat")
belul = 0
seged = 0
for i in adatok:
    if len(i[1]) > 3:
        seged = int(i[0])
    elif i[1] == "]":
        belul += int(i[0]) - int(seged)

print(f"Az út {round(belul/tavolsag * 100, 2)} százaléka vezet településen belül.")

print("\n5. feladat")
vtelepules = input('Adja meg egy település nevét! ')
tablak = 0
kezd = 0
for index, szakasz in enumerate(adatok):
    if szakasz[1] == vtelepules:
        kezd = index


index = kezd
while adatok[index][1] != "]":
    if adatok[index][1][0].isdigit():
        tablak += 1
    index += 1

print(f"A sebességkorlátozó táblák száma: {tablak}")
print(f"Az út hossza a településen belül {int(adatok[index][0]) - int(adatok[kezd][0])} méter. ")

print("\n6. feladat")
telepulesek = []
for utszakasz in adatok:
    if len(utszakasz[1]) >= 4:
        telepules = [utszakasz[1], utszakasz[0]]
    elif utszakasz[1] == ']':
        telepules.append(utszakasz[0])
        telepulesek.append(telepules)
        telepules = []
for index, telepules in enumerate(telepulesek):
    if telepules[0] == vtelepules:
        if index == 0:
            print(f'A legközelebbi település: {telepulesek[index + 1][0]}')
        elif index == len(telepulesek) - 1:
            print(f'A legközelebbi település: {telepulesek[index - 1][0]}')
        else:
            elotte = int(telepulesek[index][1]) - int(telepulesek[index - 1][2])
            utana = int(telepulesek[index + 1][1]) - int(telepulesek[index][2])
            if elotte <= utana:
                print(f'A legközelebbi település: {telepulesek[index - 1][0]}')
            else:
                print(f'A legközelebbi település: {telepulesek[index + 1][0]}')
