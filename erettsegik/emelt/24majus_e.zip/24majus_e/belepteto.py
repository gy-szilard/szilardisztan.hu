adatok = []

with open("bedat.txt", "r") as ff:
    for i in ff:
        sor = i.strip().split(" ")
        adatok.append(sor)

print("2. feladat")
print(f"Az első tanuló {adatok[0][1]}-kor lépett be a főkapun.")
print(f"Az utolsó tanuló {adatok[-1][1]}-kor lépett ki a főkapun.")

#print("3. feladat")
be = []
for i in adatok:
    ora, perc = map(int, i[1].split(":"))
    if ora == 7 and 50 < perc <= 59:
        be.append(i)
    elif ora == 8 and 00 <= perc <= 15:
        be.append(i)

with open("kesok.txt", "w") as f:
    for i in be:
        f.write(i[1] + " " + i[0] + "\n")

print("4. feladat")
ebed = 0
for i in adatok:
    if int(i[2]) == 3:
        ebed += 1
print(f"A menzán aznap {ebed} tanuló ebédelt.")

print("5. feladat")
konyvtar = []
for i in adatok:
    if int(i[2]) == 4:
        if i[0] not in konyvtar:
            konyvtar.append(i[0])
print(f"Aznap {len(konyvtar)} tanuló kölcsönzött a könyvtárban.")
if len(konyvtar) > ebed:
    print("Többen voltak, mint a menzán.")
else:
    print("Nem voltak többen, mint a menzán.")

print("6. feladat")
print('Az érintett tanulók:')
diakok_reggel = []
for esemeny in adatok:
    if esemeny[2] == '1' and esemeny[1] <= '10:50':
        diakok_reggel.append(esemeny[0])
    elif esemeny[2] == '2' and esemeny[1] <= '10:50':
        diakok_reggel.remove(esemeny[0])
    elif esemeny[2] == '1' and '10:50' < esemeny[1] < '11:00' and esemeny[0] in diakok_reggel:
        print(esemeny[0], end=' ')

print("\n7. feladat")
tanulo = input("Egy tanuló azonosítója=")
tanuloo = []
for i in adatok:
    if i[0] == tanulo and i[2] == "1" and i[2] not in tanuloo:
        tanuloo.append(i[1])
for i in range(len(adatok) - 1, -1, -1):
    if adatok[i][0] == tanulo and adatok[i][2] == "2" and adatok[i][2] not in tanuloo:
        tanuloo.append(adatok[i][1])
ora1, perc1 = map(int, tanuloo[0].split(":"))
ora2, perc2 = map(int, tanuloo[1].split(":"))

ora = ora2 - ora1
perc = perc2 - perc1
if perc < 0:
    perc += 60
    ora -= 1
print(f"A tanuló érkezése és távozása között {ora} óra {perc} perc telt el. ")
if len(tanuloo) == 0:
    print("Ilyen azonosítójú tanuló aznap nem volt az iskolában.")