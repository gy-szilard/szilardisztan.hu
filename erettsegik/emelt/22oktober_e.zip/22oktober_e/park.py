adatok = []

agyasszam = 0
with open("felajanlas.txt", "r") as ff:
    for i in ff:
        sor = i.strip().split()
        if len(sor) == 3:
            adatok.append(sor)
        else:
            agyasszam = int(sor[0])

print("2. feladat")
print(f"A felajánlások száma {len(adatok)}")

print("3. feladat")
bejarat = []
for i in range(len(adatok)):
    if int(adatok[i][0]) > int(adatok[i][1]):
        bejarat.append(i+1)
print("A bejárat mindékt oldalán ültetők száma: ", end="")
for j in bejarat:
    print(j, end=" ")

print("\n4. feladat")
agyas = int(input("Adja meg az ágyás sorszámát! "))
hanyszor = 0
szinek = []
for i in adatok:
    if agyas >= int(i[0]) and agyas <= int(i[1]):
        hanyszor += 1
        if i[2] not in szinek:
            szinek.append(i[2])
print(f"A felajánlók száma: {hanyszor}")
print(f"A virágágyás színe, ha csak az első ülteti be {szinek[0]}")
print("A virágágyás színei: ", end="")
for i in szinek:
    print(i, end=" ")

print("\n5. feladat")
beultetve = set()
vallalt_db = 0
for felajanlas in adatok:
    if int(felajanlas[0]) < int(felajanlas[1]):
        vallalt_db += int(felajanlas[1]) - int(felajanlas[0]) + 1
        for agyas in range(int(felajanlas[0]), int(felajanlas[1])+1):
            beultetve.add(agyas)
    else:
        vallalt_db += agyasszam - int(felajanlas[0]) + 1 + int(felajanlas[1])
        for agyas in range(int(felajanlas[0]), agyasszam + 1):
            beultetve.add(agyas)
        for agyas in range(1, int(felajanlas[1]) + 1):
            beultetve.add(agyas)
if len(beultetve) == agyasszam:
    print('Minden ágyás beültetésére van jelentkező.')
elif vallalt_db >= agyasszam:
    print('Átszervezéssel megoldható a beültetés.')
else:
    print('A beültetés nem oldható meg.')

#print('\n6. feladat')
vegleges = []
for index in range(agyasszam):
    vegleges.append(['#', 0])
for srsz, felajanlas in enumerate(adatok, start=1):
    for agyas_sorszama in range(1, len(adatok) + 1):
        if int(felajanlas[0]) <= agyas_sorszama <= int(felajanlas[1]) \
                or int(felajanlas[0]) > int(felajanlas[1]) and (
                int(felajanlas[0]) <= agyas_sorszama or agyas_sorszama <= int(felajanlas[1])):
            if vegleges[agyas_sorszama - 1][1] == 0:
                vegleges[agyas_sorszama - 1][0] = felajanlas[2]
                vegleges[agyas_sorszama - 1][1] = srsz
with open('szinek.txt', 'w') as szinek:
    for agyas in vegleges:
        print(agyas[0], agyas[1], file=szinek)