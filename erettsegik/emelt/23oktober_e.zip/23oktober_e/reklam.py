adatok = []

with open("rendel.txt", "r") as ff:
    for i in ff:
        sor = i.strip().split(" ")
        adatok.append(sor)

print("2. feladat:")
print(f"A rendelések száma: {len(adatok)}")

print("3. feladat:")
nap = int(input("Kérem, adjon meg egy napot: "))
rendeles = 0
for i in adatok:
    if int(i[0]) == nap:
        rendeles += 1
print(f"A rendelések száma az adott napom: {rendeles}")

print("4. feladat:")
volt = []
for i in adatok:
    if i[1] == "NR" and i[0] not in volt:
        volt.append(i[0])

if 30 - len(volt) > 0:
    print(f"{30 - len(volt)} nap nem volt a reklámban nem érintett városból rendelés")
else:
    print("Minden nap volt rendelés a reklámban nem érintett városból")

print("5. feladat:")
maxdb = 0
for i in adatok:
    if int(i[2]) > maxdb:
        maxdb = int(i[2])
for i in adatok:
    if maxdb == int(i[2]):
        print(f"A legnagyobb darabszám: {maxdb}, a rendelés napja: {i[0]}")
        break

#print("6. feladat:")
def osszes(varos, nap):
    db = 0
    for i in adatok:
        if i[1] == varos and int(i[0]) == nap:
            db += int(i[2])
    return db

print("7. feladat:")
print(f"A rendelt termékeke darabszáma a 21. napon PL: {osszes("PL", 21)}, TV: {osszes("TV", 21)}, NR: {osszes("NR", 21)}")

print("8. feladat:")
stat = {
    'elso': {
        'PL': 0,
        'TV': 0,
        'NR': 0
    },
    'masodik': {
            'PL': 0,
            'TV': 0,
            'NR': 0
        },
    'harmadik': {
            'PL': 0,
            'TV': 0,
            'NR': 0
        },
}
for i in adatok:
    if 1 <= int(i[0]) <= 10:
        harmad = 'elso'
    elif 11 <= int(i[0]) <= 20:
        harmad = 'masodik'
    else:
        harmad = 'harmadik'
    stat[harmad][i[1]] += 1

print('Napok', '1..10', '11..20', '21..30', sep='\t')
print('PL\t\t', stat['elso']['PL'], '\t', stat['masodik']['PL'], '\t', stat['harmadik']['PL'])
print('TV\t\t', stat['elso']['TV'], '\t', stat['masodik']['TV'], '\t', stat['harmadik']['TV'])
print('NR\t\t', stat['elso']['NR'], '\t', stat['masodik']['NR'], '\t', stat['harmadik']['NR'])

with open('kampany.txt', 'w') as kampany:
    print('Napok', '1..10', '11..20', '21..30', sep='\t', file=kampany)
    print('PL\t\t', stat['elso']['PL'], '\t', stat['masodik']['PL'], '\t', stat['harmadik']['PL'], file=kampany)
    print('TV\t\t', stat['elso']['TV'], '\t', stat['masodik']['TV'], '\t', stat['harmadik']['TV'], file=kampany)
    print('NR\t\t', stat['elso']['NR'], '\t', stat['masodik']['NR'], '\t', stat['harmadik']['NR'], file=kampany)