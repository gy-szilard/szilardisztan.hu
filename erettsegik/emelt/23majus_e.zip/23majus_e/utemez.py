adatok = []
with open("taborok.txt", "r") as ff:
    for i in ff:
        sor = i.strip().split()
        adatok.append(sor)

print("2. feladat")
print(f"Az adatsorok száma: {len(adatok)}")
print(f"Az először rögzített tábor témája: {adatok[0][5]}")
print(f"Az utoljára rögzített tábor témája: {adatok[-1][5]}")

print("3. feladat")
zenei = []
for i in adatok:
    if i[5] == "zenei":
        zenei.append(i)
if len(zenei) != 0:
    for i in zenei:
        print(f"Zenei tábor kezdődik {i[0]}. hó {i[1]}. napján.")
else:
    print("Nem volt zenei tábor.")

print("4. feladat")
maximum = 0
for i in adatok:
    if len(i[4]) > maximum:
        maximum = len(i[4])
for i in adatok:
    if len(i[4]) == maximum:
        print(f"{i[0]} {i[1]} {i[5]}")

#print("5. feladat")
def sorszam(honap: int, nap: int):
    if honap == 6:
        return nap - 15
    elif honap == 7:
        return nap + 15
    elif honap == 8:
        return nap + 46

print("6. feladat")
ho = int(input("hó: "))
nap = int(input("nap: "))
hany = 0
szamlalo = 0
for i in adatok:
    if sorszam(int(i[0]), int(i[1])) <= sorszam(ho, nap) <= sorszam(int(i[2]), int(i[3])):
        szamlalo += 1
print(f'Ekkor éppen {szamlalo} tábor tart.')


print("7.feladat")
megjelolt = []
tanulo = 'L'  # input('Adja meg egy tanuló betűjelét: ')
for tabor in adatok:
    if tanulo in tabor[4]:
        megjelolt.append(tabor)

megjelolt.sort(key=lambda tabor: sorszam(int(tabor[0]), int(tabor[1])))
with open('egytanulo.txt', 'w', encoding='utf-8') as celfajl:
    for tabor in megjelolt:
        print(f'{tabor[0]}.{tabor[1]}-{tabor[2]}.{tabor[3]}. {tabor[5]}',
              file=celfajl)

utkozes = False
for index in range(len(megjelolt) - 1):
    if sorszam(int(megjelolt[index][2]), int(megjelolt[index][3])) \
            >= sorszam(int(megjelolt[index+1][0]), int(megjelolt[index+1][1])):
        utkozes = True
if utkozes:
    print('Nem mehet el mindegyik táborba.')
else:
    print('Elmehet mindegyik táborba.')