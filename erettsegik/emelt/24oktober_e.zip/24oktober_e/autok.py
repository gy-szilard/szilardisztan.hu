adatok = []

with open("jeladas.txt", "r") as ff:
    for i in ff:
        sor = i.strip().split()
        adatok.append(sor)

print("2. feladat:")
print(f"Az utolsó jeladás időpontja {adatok[-1][1]}:{adatok[-1][2]}, a jármű rendszáma {adatok[-1][0]}")

print("3. feladat:")
print(f"Az első jármű: {adatok[0][0]}")
print("A jeladásainak időpontjai: ", end="")
for i in adatok:
    if i[0] == adatok[0][0]:
        print(f"{i[1]}:{i[2]}", end=" ")

print("\n4. feladat:")
jeladas = 0
ora = input("Kérem, adja meg az órát: ")
perc = input("Kérem, adja meg az percet: ")
for i in adatok:
    if i[1] == ora and i[2] == perc:
        jeladas += 1
print(f"A jeladások száma: {jeladas}")

print("5. feladat:")
max_seb = 0
for i in adatok:
    if int(i[3]) > max_seb:
        max_seb = int(i[3])
print(f"A legnagyobb sebesség km/h: {max_seb}")
print("A járművek: ", end="")
for i in adatok:
    if int(i[3]) == max_seb:
        print(i[0], end=" ")



print("\n6. feladat:")
keresett = input("Kérem, adja meg a rendszámot: ")
meresek = []
talalat = False
for adatsor in adatok:
    if adatsor[0] == keresett:
        meresek.append([adatsor[0], adatsor[1], adatsor[2], adatsor[3], 0])
        talalat = True

def ora(h, p):
    return h + (p / 60)

if talalat:
    for index in range(1, len(meresek)):
        t = ora(int(meresek[index][1]), int(meresek[index][2])) - ora(int(meresek[index-1][1]), int(meresek[index-1][2]))
        v = int(meresek[index-1][3])
        s = v * t
        meresek[index][-1] = meresek[index - 1][-1] + s
    for meres in meresek:
        print(f"{meres[1]}:{meres[2]} {meres[-1]:.1f} km")
else:
    print("Nem találtam ilyen rendszámot az adatok között.")

#print("7. feladat:")
autok = {}
for adatsor in adatok:
    if adatsor[0] not in autok:
        autok[adatsor[0]] = []
    autok[adatsor[0]].append([adatsor[1], adatsor[2]])

with open('ido.txt', 'w') as kimenet:
    for szgk, meresek in autok.items():
        print(szgk, meresek[0][0], meresek[0][1], meresek[-1][0], meresek[-1][1], file=kimenet)