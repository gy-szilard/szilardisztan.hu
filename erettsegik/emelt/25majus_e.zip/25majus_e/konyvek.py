adatok = []

with open("kiadas.txt", "r", encoding="UTF-8") as ff:
    for i in ff:
        sor = i.strip().split(";")
        adatok.append(sor)

print("2. feladat:")
szerzo = input("Szerző: ")
mu = 0
for i in adatok:
    igen = i[3].split(":")
    if igen[0] == szerzo:
        mu += 1
if mu > 0:
    print(f"{mu} könyvkiadás")
else:
    print("Nem adtak ki")

print("3. feladat:")
maxkiadas = 0
hanyszor = 0
for i in adatok:
    if int(i[4]) > maxkiadas:
        maxkiadas = int(i[4])
for i in adatok:
    if maxkiadas == int(i[4]):
        hanyszor += 1

print(f"Legnagyobb példányszám: {maxkiadas}, előfordult {hanyszor} alkalommal")

print("4. feladat:")
for i in adatok:
    if i[2] == "kf" and int(i[4]) >= 40000:
        print(f"{i[0]}/{i[1]} {i[3]}")
        break

print("5. feladat:")
osszes_ev = []
for i in adatok:
    if i[0] not in osszes_ev:
        osszes_ev.append(i[0])

print("Év\t\tMagyar kiadás\tMagyar példányszám\t\tKülföldi kiadás\tKülföldi példányszám")
for i in osszes_ev:
    magyar_db = 0
    magyar_peldany = 0
    kulfoldi_db = 0
    kulfoldi_peldany = 0

    for sor in adatok:
        if sor[0] == i:
            if sor[2] == "ma":
                magyar_db += 1
                magyar_peldany += int(sor[4])
            elif sor[2] == "kf":
                kulfoldi_db += 1
                kulfoldi_peldany += int(sor[4])

    print(f"{i}\t\t\t{magyar_db}\t\t\t\t{magyar_peldany}\t\t\t{kulfoldi_db}\t\t\t\t{kulfoldi_peldany}")

print("6. feladat:")
kiadasok = {}
for konyv in adatok:
    leiras = konyv[3]
    if konyv[3] not in kiadasok:
        kiadasok[leiras] = [int(konyv[4])]
    else:
        if int(konyv[4]) > kiadasok[leiras][0]:
            kiadasok[konyv[3]].append(int(konyv[4]))

print('Legalább kétszer, nagyobb példányszámban újra kiadott könyvek:')
for konyv in kiadasok:
    if len(kiadasok[konyv]) >= 3:
        print(konyv)